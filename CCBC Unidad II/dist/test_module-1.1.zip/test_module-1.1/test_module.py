def area(a: int, b: int, c: int) -> int:
    ar = 2*(a*b + a*c + b*c)
    return ar


def volumen(a: int, b: int, c: int) -> int:
    vol = a*b*c
    return vol
