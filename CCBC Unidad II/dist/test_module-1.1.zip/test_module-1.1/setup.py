from setuptools import setup

setup(
    name='test_module',
    version='1.1',
    description='The equations example Application Programming',
    author='CCBC',
    author_email='profesor@gmail.com',
    url='trello.com/pa',
    py_modules=['test_module'],
)
